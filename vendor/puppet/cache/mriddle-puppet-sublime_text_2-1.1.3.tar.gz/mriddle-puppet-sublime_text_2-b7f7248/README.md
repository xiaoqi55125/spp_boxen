# Sublime Text 2 Puppet Module for Boxen

## Usage

```puppet
include sublime_text_2
```

## Required Puppet Modules

None.
