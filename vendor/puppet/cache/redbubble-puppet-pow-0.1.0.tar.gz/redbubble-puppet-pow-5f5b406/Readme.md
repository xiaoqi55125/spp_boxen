# Pow! Puppet Module for Boxen

Installs and sets up Pow!.

## Usage

```puppet
include pow
```

# Required Puppet Modules

* `boxen`
* `homebrew`
* `nodejs`

## Developing

Write code.

